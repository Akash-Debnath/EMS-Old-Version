<?php

//print_r($grade_list);
$skin = "skin-blue";
?>
<?php include 'header.php'; ?>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/pagination.css">
<link
	href="<?php echo base_url();?>assets/lib/bootstrap/css/datepicker3.css"
	type="text/css" rel="stylesheet" />
<style>

	.forScroll {
		height: 250px;
		overflow-y: auto;
	}

	.padding-5{
		padding: 4px 6px;
	}

	.no-border{
		border: 0;
	}

	.ul-padding-left{
		list-style-type: none;
		padding-left: 20px;
	}

	.m-b{
		margin-bottom: 15px;
	}


</style>


    <div class="container">
        <div class="table-responsive">
            <table class="table borderless">
                <thead>
                    
                </thead>
                <tbody>
                    <tr>
                        <td>Mobile</td>
                        <td><?= (isset($edited->mobile)) ? $edited->mobile : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','mobile','<?= (isset($edited->mobile)) ? $edited->mobile : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Home Phone</td>
                        <td><?= (isset($edited->phone)) ? $edited->phone : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','phone','<?= (isset($edited->phone)) ? $edited->phone : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Present Address</td>
                        <td><?= (isset($edited->present_address)) ? $edited->present_address : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','present_address','<?= (isset($edited->present_address)) ? $edited->present_address : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Permanent Address</td>
                        <td><?= (isset($edited->permanent_address)) ? $edited->present_address : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','permanent_address','<?= (isset($edited->permanent_address)) ? $edited->present_address : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Last Achievement</td>
                        <td><?= (isset($edited->last_edu_achieve)) ? $edited->last_edu_achieve : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','last_edu_achieve','<?= (isset($edited->last_edu_achieve)) ? $edited->last_edu_achieve : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Experience</td>
                        <td><?= (isset($edited->experience)) ? $edited->experience : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','experience','<?= (isset($edited->experience)) ? $edited->experience : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Date Of Birth</td>
                        <td><?= (isset($edited->dob)) ? $edited->dob : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','dob','<?= (isset($edited->dob)) ? $edited->dob : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Blood Group</td>
                        <td><?= (isset($edited->blood_group)) ? $edited->blood_group : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','blood_group','<?= (isset($edited->blood_group)) ? $edited->blood_group : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><?= (isset($edited->gender)) ? $edited->gender : NULL ?></td>
                        <td><button type="button" class="btn btn-danger fa fa-trash" onclick="deleteFun('<?= (isset($edited->id)) ? $edited->id : NULL ?>','gender','<?= (isset($edited->gender)) ? $edited->gender : NULL ?>')"></button></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td><?php
                            if(isset($edited->status)){
                                if($edited->status =="N"){
                                    echo "<button class='btn btn-warning' style='cursor:no-drop'>Not approved</button>";
                                }elseif($edited->status=="R"){
                                    echo "<button class='btn btn-danger' style='cursor:no-drop'>Rejected</button>";
                                }elseif($edited->status=="A"){
                                    echo "<button class='btn btn-success' style='cursor:no-drop'>Approved</button>";
                                }
                            }else{
                                echo "<button class='btn btn-danger' style='cursor:no-drop'>Status</button>";
                            }
                        ?></td>
                        
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

<div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Are you sure want to 'Delete' this item</h4>
        </div>
        <div class="modal-body text-right">
		<br>
			<form action="<?php echo base_url()?>user/delete_Edit" method="post">
				<input type="hidden" name="id" id="id">
				<input type="hidden" name="column" id="column">
				<input type="hidden" name="value" id="value">
				<button type="submit" class="btn btn-danger">Delete</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</form>
        </div>
      </div>
    </div>
</div>
<?php include 'footer.php'; ?>



<link href="<?php echo base_url();?>assets/css/user.css"
	  type="text/css" rel="stylesheet" />
<script
	src="<?php echo base_url();?>assets/lib/bootstrap/js/bootstrap-select.js"
	type="text/javascript"></script>
<link
	href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap-select.css"
	type="text/css" rel="stylesheet" />
<script
	src="<?php echo base_url();?>assets/lib/bootstrap/js/bootstrap-datepicker.js"
	type="text/javascript"></script>
<link
	href="<?php echo base_url();?>assets/lib/bootstrap/css/datepicker3.css"
	type="text/css" rel="stylesheet" />

<script src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
<script
	src="<?php echo base_url();?>assets/js/additional-methods.min.js"></script>

<script src="https://apis.google.com/js/platform.js?onload=onLoadCallback" async defer></script>


<script type="text/javascript">


	$(document).ready(function() {

		

	});
    function deleteFun(id,column,value) {
        $('#deleteModal').modal('show');
        $('#id').val(id);
        $('#column').val(column);
        $('#value').val(value);
        console.log(id+" "+column+" "+value);
    }

</script>

